# encoding: utf-8
from scrapy.dupefilters import BaseDupeFilter
import zlib
from BloomfilterOnRedis import BloomFilter

#定义一个url去重器
class DupeFilter(BaseDupeFilter):

    def __init__(self, server, key):
        self.server = server
        self.key = key
        self.bf = BloomFilter(server, key, blockNum=1)

    def request_seen(self, url):
        if self.bf.isContains(url):
            return True
        else:
            self.bf.insert(url)
            return False

    def close(self, reason):
        """Delete data on close. Called by scrapy's scheduler"""
        self.clear()

    def clear(self):
        """Clears fingerprints data"""
        self.server.delete(self.key)
