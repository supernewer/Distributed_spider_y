#!/usr/bin/env python
# coding: utf-8
__author__ = 'supernew'


import threading
import time

"""全局定义了一个“Flag”，
如果“Flag”值为 False，那么当程序执行 event.wait 方法时就会阻塞，
如果“Flag”值为True，那么event.wait 方法时便不再阻塞
    clear：将“Flag”设置为False
    set：将“Flag”设置为True
"""
"""无论是暂停还是停止, 都不是瞬时的, 必须等待run函数内部的运行到达标志位判断时才有效. 也就是说操作会滞后一次."""
class Job(threading.Thread):

    def __init__(self,target):
        threading.Thread.__init__(self,target=target)
        self.__flag = threading.Event()     # 用于暂停线程的标识
        self.__flag.set()       # 设置为True
        self.__running = threading.Event()      # 用于停止线程的标识
        self.__running.set()      # 将running设置为True
        self.target=target


    def run(self):
        while self.__running.isSet():
            self.__flag.wait()      # __flag为True时立即返回, 为False时阻塞直到内部的标识位为True后返回
            print "爬虫已经启动"

    def pause(self):
        self.__flag.clear()     # 设置为False, 让线程阻塞

    def resume(self):
        self.__flag.set()    # 设置为True, 让线程停止阻塞

    def stop(self):
        self.__flag.set()       # 将线程从暂停状态恢复, 如过已经暂停的话
        self.__running.clear()        # 设置为False

if __name__ == "__main__":
    a = Job()
    a.start()
    time.sleep(3)
    a.pause()
    time.sleep(3)
    a.resume()
    time.sleep(3)
    a.pause()
    time.sleep(2)
    a.stop()
