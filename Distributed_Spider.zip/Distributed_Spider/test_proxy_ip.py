#encoding=utf8
import random
import Get_proxy_IP

__author__ = 'supernew'
import urllib
import socket

def test_proxy_ip():
    socket.setdefaulttimeout(3)
    f = open("proxy_ip")
    lines = f.readlines()
    #存储所有的代理IP
    proxys = []

    ff = open("right_proxy_ip","w")
    for i in range(0,len(lines)):
        ip = lines[i].strip("\n").split("\t")
        proxy_host = "http://"+ip[0]+":"+ip[1]
        proxy_temp = {"http":proxy_host}
        proxys.append(proxy_temp)
    url = "http://ip.chinaz.com/getip.aspx"
    for proxy in proxys:
        try:
            res = urllib.urlopen(url,proxies=proxy).read()
           # print res
            print proxy["http"]
            proxy_ip=proxy["http"]+"\n"
            ff.write(proxy_ip)
            proxy_ip.append(proxy)
        except Exception,e:
            continue

def get_random_ip():
    #存储可用的代理IP
    proxy_list=[]
    f = open("right_proxy_ip")
    lines = f.readlines()
    for line in lines:
        if line!=None:
            line=line.strip("\n")
            proxy_list.append(line)
    proxy_ip = random.choice(proxy_list)
    proxies = {'http': proxy_ip}
    return proxies

if __name__ == "__main__":
   """f = open("proxy_ip")
   lines = f.readlines()
   if lines==None:
       Get_proxy_IP.get_proxy_ips()
       print "Successfully crawl the proxy_ips!!!"""
   test_proxy_ip()
   get_random_ip()