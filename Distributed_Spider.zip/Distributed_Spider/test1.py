#coding=utf-8
import random

import re
import urllib2
import requests
import sys
import settings

reload(sys)
sys.setdefaultencoding('utf8')
def downloaditems():
    url = 'https://s.taobao.com/search?spm=a230r.1.0.0.6BUj7u&q=%E5%B8%BD%E5%AD%90&rs=up&rsclick=2&preq='
    #resp = requests.get(url)
    headers={}
    headers['User-agent'] = random.choice(settings.USER_AGENTS)
    request=urllib2.Request(url, headers=headers)
    """proxies=test_proxy_ip.get_random_ip()  #设置随机获取的代理
    proxy_s=urllib2.ProxyHandler(proxies)
    opener=urllib2.build_opener(proxy_s)
    urllib2.install_opener(opener)"""
    response = urllib2.urlopen(request)
    html_page = response.read()

    print url
    html_page.encode('utf-8') #设置编码
    title = re.findall(r'"raw_title":"([^"]+)"',html_page)  #正则保存所有raw_title的内容，这个是书名，下面是价格，地址
    price = re.findall(r'"view_price":"([^"]+)"',html_page)
    loc = re.findall(r'"item_loc":"([^"]+)"',html_page)
    x = len(title)           #每一页商品的数量
    k=0
    for i in range(0,x) :    #把列表的数据保存到文件中
        k=k+1
        strr=str(k)+'商品名：'+title[i]+'\n'+'价格：'+price[i]+'\n'+'地址：'+loc[i]+'\n'
        print strr
            #file.write(str(k*44+i+1)+'书名：'+title[i]+'\n'+'价格：'+price[i]+'\n'+'地址：'+loc[i]+'\n\n')
    #file.close()
if __name__ == '__main__':
   downloaditems()