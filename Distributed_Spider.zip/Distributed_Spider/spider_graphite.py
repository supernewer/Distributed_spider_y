#!/usr/bin/python
#-*-coding:utf-8-*-

import redis
from socket import socket
from time import time
from logger import Logger
import logging

# default values
REDIS_HOST = '118.89.176.56'
REDIS_PORT = 6379
STATS_KEY = 'crawl:stats'

class GraphiteClient(object):
    """
        The client thats send data to graphite.
        Can have some ideas from /opt/graphite/examples/example-client.py
    """
    
    def __init__(self, host="118.89.176.56", port=2003):
        self._sock = socket()
        self._sock.connect((host,port))
        self.GraphiteClient_logger= Logger('log/GraphiteClient.log',logging.DEBUG,logging.DEBUG)
    def send(self, metric, value, timestamp=None):
        try:
            self._sock.send("%s %g %s\n\n" % (metric, value, timestamp or int(time())))
        except Exception as err:
            ERROR="SocketError(GraphiteClient): " + str(err)
            self.GraphiteClient_logger.cri(ERROR)

class RedisStatsCollector(object):
    """
        Save stats data in redis for distribute situation.
    """
    
    def __init__(self, crawler):
        host = REDIS_HOST
        port = REDIS_PORT
        self.stats_key =STATS_KEY
        self.server = redis.Redis(host, port)
        
    def get_value(self, key, default=None):
        if self.server.hexists(self.stats_key, key):
            return int(self.server.hget(self.stats_key,key))
        else:
            return default

    def get_stats(self):
        return self.server.hgetall(self.stats_key)

    def set_value(self, key, value):
        self.server.hset(self.stats_key,key,value)

    def set_stats(self, stats):
        self.server.hmset(self.stats_key,stats)

    def inc_value(self, key, count=1, start=0):
        if not self.server.hexists(self.stats_key,key):
            self.set_value(key, start)
        self.server.hincrby(self.stats_key,key,count)

    def max_value(self, key, value):
        self.set_value(key, max(self.get_value(key,value),value))

    def min_value(self, key, value):
        self.set_value(key, min(self.get_value(key,value),value))

    def clear_stats(self):
        self.server.delete(self.stats_key)

    def _persist_stats(self, stats, spider):
        pass

#基于redis分布式的graphite状态收集器
class RedisGraphiteStatsCollector(RedisStatsCollector):

    GRAPHITE_HOST = '118.89.176.56'
    GRAPHITE_PORT = 2003
    GRAPHITE_IGNOREKEYS = []#to ignore it,prevent to send data to graphite
    
    def __init__(self):
        super(RedisGraphiteStatsCollector, self).__init__(self)
        host = self.GRAPHITE_HOST
        port = self.GRAPHITE_PORT
        self.ignore_keys = self.GRAPHITE_IGNOREKEYS
        self._graphiteclient = GraphiteClient(host,port)

    def _get_stats_key(self,  key):
        if key is not None:
            return "scrapy.%s" % ( key)
        return "scrapy.%s" % (key)

    def set_value(self, key, value):
        super(RedisGraphiteStatsCollector, self).set_value(key, value)
        self._set_value(key, value)

    def _set_value(self, key, value):
        if isinstance(value, (int, float)) and key not in self.ignore_keys:
            k = self._get_stats_key(key)
            self._graphiteclient.send(k, value)

    def inc_value(self, key, count=1, start=0):
        super(RedisGraphiteStatsCollector, self).inc_value(key, count, start)
        self._graphiteclient.send(self._get_stats_key(key), self.get_value(key))

    def max_value(self, key, value):
        super(RedisGraphiteStatsCollector, self).max_value(key, value)
        self._graphiteclient.send(self._get_stats_key(key),self.get_value(key))

    def min_value(self, key, value):
        super(RedisGraphiteStatsCollector, self).min_value(key, value)
        self._graphiteclient.send(self._get_stats_key(key),self.get_value(key))

    def set_stats(self, stats):
        super(RedisGraphiteStatsCollector, self).set_stats(stats)
        for key in stats:
            self._set_value(key, stats[key])
