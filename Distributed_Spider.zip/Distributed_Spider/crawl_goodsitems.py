# encoding: utf-8
import logging
import random
import pymongo
import redis
from gooditems import goodsItem
from scheduler import Scheduler
from spider_graphite import RedisGraphiteStatsCollector
import test_proxy_ip
import settings
from lxml import etree
from logger import Logger
import urllib2
import json
import datetime


__author__ = 'supernew'
# !/usr/bin/env python
#对指定url的网页进行下载


class Downloaditems(object):
     #定义日志的记录信息
    crawl_items_logger= Logger('log/crawl_items.log',logging.DEBUG,logging.DEBUG)
    mongodb_logger= Logger('log/Mongodb.log',logging.DEBUG,logging.DEBUG)
    #定义开始爬取的时间
    goodsItem_Collector=RedisGraphiteStatsCollector()
    start_time=datetime.datetime.now()
    last_time=''#定义最后爬取的时间
    collector_key="mongodb_crawl_GoodsItems_nums"
    #爬取商品的数目
    item_num1=0
    item_num2=0

    def uploaditems(self, goodItem):
        collection_name = 'jditems'
        try:
            self.mongoserver=pymongo.MongoClient(settings.MONGO_URI)
            self.db = self.mongoserver[settings.MONGO_DATABASE1]
        except Exception,e:
            self.mongodb_logger.error(e)
        goodsItem={
            'ID':'',
            'name':'',
            'shop_name':'',
            'CommentCountStr':'',
            'GoodCountStr':'',
            'GeneralCountStr':'',
            'PoorCountStr':'',
        }
        goodsItem['ID']=goodItem.ID
        goodsItem['name']=goodItem.name
        goodsItem['shop_name']=goodItem.shop_name
        goodsItem['CommentCountStr']=goodItem.CommentCountStr
        goodsItem['GoodCountStr']=goodItem.GoodCountStr
        goodsItem['GeneralCountStr']=goodItem.GeneralCountStr
        goodsItem['PoorCountStr']=goodItem.PoorCountStr
        #self.db[collection_name].insert(document)
        self.db[collection_name].update({'link': goodsItem['ID']}, {'$set': goodsItem}, True)
        self.item_num2=self.item_num2+1
        self.last_time=datetime.datetime.now()
        interval=self.last_time-self.start_time
        total_sec = interval.total_seconds()
        if total_sec>60 and total_sec<70:
            num=self.item_num2-self.item_num1
            self.item_num1=self.item_num2
            self.start_time=self.last_time
            self.goodsItem_Collector._set_value(self.collector_key,num)
            message='The Spider has crawled %s items around one minutes'%num
            self.mongodb_logger.info(message)



    def downloaditems(self, crawl_scheduler):
        headers = {}
        while True:
             if not crawl_scheduler.get_goods_queue_len()==0:
                url=crawl_scheduler.get_goods_url()
                message='Downloading: %s'%url
                self.crawl_items_logger.info(message)
                #为了下载更可靠，控制用户代理的设定
                headers['User-agent'] = random.choice(settings.USER_AGENTS)
                try:
                    self.last_time=datetime.datetime.now()
                    request=urllib2.Request(url, headers=headers)
                    proxies=test_proxy_ip.get_random_ip()  #设置随机获取的代理
                    proxy_s=urllib2.ProxyHandler(proxies)
                    opener=urllib2.build_opener(proxy_s)
                    urllib2.install_opener(opener)
                    response = urllib2.urlopen(request)
                    html_page = response.read()
                    html = etree.HTML(html_page.lower())
                    goods = html.xpath('//li[@class="gl-item"]')
                    for good in goods:
                        item = goodsItem()
                        #判别是否存在相应标签，若不存在则置为空，若存在则取相应的值
                        #取商品ID
                        if good.xpath('./div/@data-sku')==None:
                            item.ID=''#若不存在则置为空
                            message='The ID of this good is null(can not match the tag!)'
                            self.crawl_items_logger.debug(message)
                        else:
                            item.ID = good.xpath('./div/@data-sku')[0]
                        #取商品名称
                        if good.xpath('./div/div[@class="p-name"]/a/em/text()')==None:
                            item.name=''
                            message='The name of this good is null(can not match the tag!)'
                            self.crawl_items_logger.debug(message)
                        else:
                            item.name = good.xpath('./div/div[@class="p-name"]/a/em/text()')[0]
                        #获取店铺名
                        if good.xpath('./div/div[@class="p-shop"]/@data-shop_name')==None:
                            item.shop_name=''
                            message='The shop name of this good is null(can not match the tag!)'
                            self.crawl_items_logger.debug(message)
                        else:
                            item.shop_name = good.xpath('./div/div[@class="p-shop"]/@data-shop_name')[0]
                        #获取商品的具体路径
                        if good.xpath('./div/div[@class="p-img"]/a/@href')==None:
                            item.link=''
                            message='The link of this good is null(can not match the tag!)'
                            self.crawl_items_logger.debug(message)
                        else:
                            item.link= good.xpath('./div/div[@class="p-img"]/a/@href')[0]
                        #获取商品的评价信息
                            url = "https://club.jd.com/comment/productCommentSummaries.action?referenceIds=" + str(item.ID)
                            try:
                                request=urllib2.Request(url)
                                response = urllib2.urlopen(request).read()
                            except Exception,e:
                                self.crawl_items_logger.error(message)
                            js = json.loads(str(response).decode('GBK'))
                            item.CommentCountStr =js['CommentsCount'][0]['CommentCountStr']
                            item.GoodCountStr = js['CommentsCount'][0]['GoodCountStr']
                            item.GeneralCountStr= js['CommentsCount'][0]['GeneralCountStr']
                            item.PoorCountStr=js['CommentsCount'][0]['PoorCountStr']
                            self.uploaditems(item)
                except Exception,e:
                    print e
                    self.crawl_items_logger.cri(e)
                    continue
             else:
                message='The queue is null'
                self.crawl_items_logger.debug(message)
                break
if __name__ == '__main__':
    jditems=Downloaditems()
    Redis_server= redis.Redis('118.89.176.56',6379)
    dupefilter_key=settings.JD_DUPEFILTER_KEY
    urls_queue_key=settings.JD_URLS_QUEUE_KEY
    goods_queue_key=settings.JD_GOODS_QUEUE_KEY
    crawl_scheduler=Scheduler(Redis_server,dupefilter_key,urls_queue_key,goods_queue_key)
    jditems.downloaditems(crawl_scheduler)




