#正文获取
from lxml import etree
import urllib.request
import re
from bs4 import BeautifulSoup,Comment
def getcontentfromweb(src):  #获取网页
  req = urllib.request.Request(src)
  response = urllib.request.urlopen(req)
  try:
    html_page = response.read().decode('utf-8')
  except:
    response = urllib.request.urlopen(req)
    html_page = response.read().decode('gbk')
  return html_page

def filter_tags(html_str):#去除各种标签
    soup =BeautifulSoup(html_str)
    #title =soup.title.string.encode().decode('utf-8')
    [script.extract() for script in soup.findAll('script')]
    [style.extract() for style in soup.findAll('style')]
    comments = soup.findAll(text=lambda text: isinstance(text, Comment))
    [comment.extract() for comment in comments]
    reg1 = re.compile("<[^>]*>")
    content = reg1.sub('', soup.prettify()).split('\n')
    return content

def getcontent(lst):#获取正文
    lstlen = [len(x) for x in lst]
    threshold=50
    startindex = 0
    maxindex = lstlen.index(max(lstlen))
    endindex = 0
    for i,v in enumerate(lstlen[:maxindex-3]):
        if v> threshold and lstlen[i+1]>5 and lstlen[i+2]>5 and lstlen[i+3]>5:
            startindex = i
            break
    for i,v in enumerate(lstlen[maxindex:]):
        if v< threshold and lstlen[maxindex+i+1]<10 and lstlen[maxindex+i+2]<10 and lstlen[maxindex+i+3]<10:
            endindex = i
            break
    content =['*'+x.strip()+'*' for x in lst[startindex:endindex+maxindex] if len(x.strip())>0]
    return content

def run(url): #运行函数
    ctthtml=getcontentfromweb(url)
    content =filter_tags(ctthtml)
    newcontent =getcontent(content)
    ctt =''.join(newcontent)
    hj=ctt.split("**")
    con=''
    for i in hj:
      if i!="":
        if regex(i):
          con+="<p>"+i+"</p>"
    return con


def is_chinese(uchar):
  """判断一个unicode是否是汉字"""
  zhPattern = re.compile(u'[\u4e00-\u9fa5]+')#中文字符
  #zhPattern = re.compile(u'[\u3000|\uff01-\uff0f|\uff1a-\uff20|\uff3b-\uff40|\uff5b-\uff5e]+')#中文标点(全角)
  #string.punctuation#英文符号
  #string.printable#数字和英文大小写
  match = zhPattern.search(uchar)
  if match:
    return True
  else:
    return False

def regex(stri): #判断中文在字符串中的比例
  leng=len(stri)
  L=0
  for x in stri:
    if is_chinese(x):
      L+=1
  if L/leng>0.1:
    return True


#搜狐
def geturl(url):
  Url=url
  req = urllib.request.Request(Url)
  response = urllib.request.urlopen(req)
  html_page = response.read()  
  g=html_page.decode('gbk')
  html = etree.HTML(g)
  hrefs = html.xpath("//a")
  for a in hrefs:
    if 'href' in a.attrib:
      val = a.attrib['href']
      #将val存入队列




#搜狐 提取新闻规则（将所有url放入队列）
def url(url):
  Url=url
  req = urllib.request.Request(Url)
  response = urllib.request.urlopen(req)
  html_page = response.read()
  """
  with open("D:\GGGGGG.txt","w",encoding="utf-8") as f:
    f.write(html_page.decode("gbk"))
  with open("D:\GGGGGG.txt","r",encoding="utf-8") as f:
    g=f.read()
    """
  g=html_page.decode('gbk')
  html = etree.HTML(g)
  hrefs = html.xpath("//a")
  for a in hrefs:
    if 'href' in a.attrib:
      val = a.attrib['href']
      if re.match(r'^http://www.sohu.com',val):
        h=re.match(r'^http://www.sohu.com/a/\w*(-|_|)\w*\d+\w*',val)
        #h=re.match(r'^http://www.sohu.com/a/\w*(-|_|)\w*\d+\w*',val.split("//")[1].split("/")[-1].split(".")[0])
        if h:
          req = urllib.request.Request(h.group())
          response = urllib.request.urlopen(req)
          html_page = response.read().decode('gbk')  
          htmlx = etree.HTML(html_page)
          htmlx.xpath('//h1[@itemprop="headline"]')#提取标题
          #调用正文提取函数
          #存入队列


#网易
def url(url):  #选取url进入队列，输入根URL
  delete=["index","review","weather","photo"]
  Url=url
  req = urllib.request.Request(Url)
  response = urllib.request.urlopen(req)
  html_page = response.read()  
  html = etree.HTML(html_page)
  hrefs = html.xpath("//a")
  for a in hrefs:
    if 'href' in a.attrib:
      val = a.attrib['href']
      h=re.match(r'^http://news.163.com/\w{4,7}/$',val)
      if h and "photo" not in h.group() and "index" not in h.group() and "review" not in h.group() and "weather" not in h.group():
      #放入队列


#从队列中取出
def url(url):  #选取新闻网页
  Url=url
  req = urllib.request.Request(Url)
  response = urllib.request.urlopen(req)
  html_page = response.read()  
  html = etree.HTML(html_page)
  hrefs = html.xpath("//a")
  urlt=[]
  for a in hrefs:
    if 'href' in a.attrib:
      val = a.attrib['href']
      if re.match(r'^http',val):
        h=re.match(r'\w*(-|_|)\w*\d+\w*',val.split("//")[1].split("/")[-1].split(".")[0])
        if h and ("zajia" in val or "news" in val) and "photo" not in val:
          req = urllib.request.Request(h.group())
          response = urllib.request.urlopen(req)
          html_page = response.read().decode('gbk')  
          htmlx = etree.HTML(html_page)
          htmlx.xpath('//div[@itemprop="articleBody"]/p/strong')#取标题
          #调用正文提取函数
          #将上面两个存入数据库


