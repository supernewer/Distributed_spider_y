# encoding: utf-8
import logging
import random
import re
import pymongo
import redis
from Split_text import run
from newsitems import newsItem
from scheduler import Scheduler
from spider_graphite import RedisGraphiteStatsCollector
import test_proxy_ip
import settings
from lxml import etree
from logger import Logger
import urllib2
import json
import datetime


__author__ = 'supernew'
# !/usr/bin/env python
#对指定url的网页进行下载


class Downloaditems(object):
     #定义日志的记录信息
    crawl_items_logger= Logger('log/crawl_items.log',logging.DEBUG,logging.DEBUG)
    mongodb_logger= Logger('log/Mongodb.log',logging.DEBUG,logging.DEBUG)
    #定义开始爬取的时间
    goodsItem_Collector=RedisGraphiteStatsCollector()
    start_time=datetime.datetime.now()
    last_time=''#定义最后爬取的时间
    collector_key="mongodb_crawl_newsItems_nums"
    #爬取新闻的数目
    item_num1=0
    item_num2=0

    def uploaditems(self,newsItem):
        collection_name = 'news'
        try:
            self.mongoserver=pymongo.MongoClient(settings.MONGO_URI)
            self.db = self.mongoserver[settings.MONGO_DATABASE2]
        except Exception,e:
            self.mongodb_logger.error(e)
        newsItem={
            'title':'',
            'text':'',
        }
        newsItem['title']=newsItem.title
        newsItem['text']=newsItem.text

        self.db[collection_name].update({'title': newsItem['title']}, {'$set': newsItem}, True)
        self.item_num2=self.item_num2+1
        self.last_time=datetime.datetime.now()
        interval=self.last_time-self.start_time
        total_sec = interval.total_seconds()
        if total_sec>60 and total_sec<70:
            num=self.item_num2-self.item_num1
            self.item_num1=self.item_num2
            self.start_time=self.last_time
            self.goodsItem_Collector._set_value(self.collector_key,num)
            message='The Spider has crawled %s news around one minutes'%num
            self.mongodb_logger.info(message)



    def downloaditems(self, crawl_scheduler):
        headers = {}
        while True:
             if not crawl_scheduler.get_goods_queue_len()==0:
                url=crawl_scheduler.get_goods_url()
                message='Downloading: %s'%url
                self.crawl_items_logger.info(message)
                #为了下载更可靠，控制用户代理的设定
                headers['User-agent'] = random.choice(settings.USER_AGENTS)
                try:
                    self.last_time=datetime.datetime.now()
                    request=urllib2.Request(url, headers=headers)
                    proxies=test_proxy_ip.get_random_ip()  #设置随机获取的代理
                    proxy_s=urllib2.ProxyHandler(proxies)
                    opener=urllib2.build_opener(proxy_s)
                    urllib2.install_opener(opener)
                    response = urllib2.urlopen(request)
                    html_page = response.read()
                    html = etree.HTML(html_page)
                    hrefs = html.xpath("//a")
                    item = newsItem()
                    for a in hrefs:
                        if 'href' in a.attrib:
                          val = a.attrib['href']
                          if re.match(r'^http',val):
                            h=re.match(r'\w*(-|_|)\w*\d+\w*',val.split("//")[1].split("/")[-1].split(".")[0])
                            if h and ("zajia" in val or "news" in val) and "photo" not in val:
                              req = urllib2.request.Request(h.group())
                              response = urllib2.request.urlopen(req)
                              html_page = response.read().decode('gbk')
                              htmlx = etree.HTML(html_page)
                              item.title= htmlx.xpath('//div[@itemprop="articleBody"]/p/strong')#取标题
                              item.text=run(h)
                              self.uploaditems(item)

                except Exception,e:
                    print e
                    self.crawl_items_logger.cri(e)
                    continue
             else:
                message='The queue is null'
                self.crawl_items_logger.debug(message)
                break
if __name__ == '__main__':
    jditems=Downloaditems()
    Redis_server= redis.Redis('118.89.176.56',6379)
    dupefilter_key=settings.WY_DUPEFILTER_KEY
    urls_queue_key=settings.WY_URLS_QUEUE_KEY
    goods_queue_key=settings.WY_GOODS_QUEUE_KEY
    crawl_scheduler=Scheduler(Redis_server,dupefilter_key,urls_queue_key,goods_queue_key)
    jditems.downloaditems(crawl_scheduler)





