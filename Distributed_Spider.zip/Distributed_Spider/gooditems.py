# encoding: utf-8
#定义商品信息列表
class goodsItem():
    link = ''  # 商品链接
    ID = ''  # 商品ID
    name = ''  # 商品名字
    CommentCountStr =''  # 评论人数
    shop_name = ''  # 店家名字
    price = ''  # 价钱
    GoodCountStr=''#好评人数
    GeneralCountStr=''#中评人数
    PoorCountStr= ''#差评人数

