# encoding=utf-8
"""如果setting文件中配置了SCHEDULER_PERSIST为True，
那么在爬虫关闭的时候scheduler会调用自己的flush函数把redis数据库中的判重和调度池全部清空，
使得我们的爬取进度完全丢失（但是item没有丢失，item数据在另一个键中储存）。
如果设置SCHEDULER_PERSIST为False，
爬虫关闭后，判重池和调度池仍然存在于redis数据库中，
则我们再次开启爬虫时，可以接着上一次的进度继续爬取"""



USER_AGENTS = [
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; AcooBrowser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Acoo Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506)",
    "Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.35; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
    "Mozilla/5.0 (Windows; U; MSIE 9.0; Windows NT 9.0; en-US)",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
    "Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
    "Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.2; .NET CLR 3.0.04506.30)",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.3 (Change: 287 c9dfb30)",
    "Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.6",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.2pre) Gecko/20070215 K-Ninja/2.1.1",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9) Gecko/20080705 Firefox/3.0 Kapiko/3.0",
    "Mozilla/5.0 (X11; Linux i686; U;) Gecko/20070322 Kazehakase/0.4.5",
    "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.8) Gecko Fedora/1.9.0.8-1.fc10 Kazehakase/0.5.6",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/535.20 (KHTML, like Gecko) Chrome/19.0.1036.7 Safari/535.20",
    "Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; fr) Presto/2.9.168 Version/11.52",
]

#定义路径的不匹配规则
NO_MATCHING=["www", "help", "vip", "app", "paimai", "cart",
             "jr", "sale", "qate", "search", "item", "order",
             "b", "red", "home", "fresh","miaosha",
             "chaoshi","yp.", "jr", "a.", "o.","o.","z."]
# 这里使用的代理IP，因为IP的存活期的限制，请定期更新下面的IP，可从http://www.xicidaili.com/ 中找免费的代理IP
PROXIES = [
    {'ip_port': '119.115.233.78:80', 'user_pass': ''},
    {'ip_port': '61.191.41.130:80', 'user_pass': ''},
    {'ip_port': '221.230.72.182:80', 'user_pass': ''},
    {'ip_port': '113.70.150.94:808', 'user_pass': ''},
    {'ip_port': '60.205.95.162:808', 'user_pass': ''},
    {'ip_port': '123.179.128.151:8080', 'user_pass': ''},
    {'ip_port': '27.18.167.39:808', 'user_pass': ''},
]

COOKIES_ENABLED = False
#配置要爬取的商品列表路径数目
CRAWL_URL_nums=100


# 配置去重队列，未匹配的队列，已匹配的商品列表队列的信息
#京东的存储结构信息
JD_DUPEFILTER_KEY="jingdong:dupefilter"
JD_URLS_QUEUE_KEY="jingdong:crawl_url"
JD_GOODS_QUEUE_KEY="jingdong:goods_list_url"
#淘宝的存储结构信息
TB_DUPEFILTER_KEY="taobao:dupefilter"
TB_URLS_QUEUE_KEY="taobao:crawl_url"
TB_GOODS_QUEUE_KEY="taobao:goods_list_url"
#网易的存储结构信息
WY_DUPEFILTER_KEY="wangyi:dupefilter"
WY_URLS_QUEUE_KEY="wangyi:crawl_url"
WY_GOODS_QUEUE_KEY="wangyi:text_url"
#搜狐的存储结构信息
SH_DUPEFILTER_KEY="souhu:dupefilter"
SH_URLS_QUEUE_KEY="souhu:crawl_url"
SH_GOODS_QUEUE_KEY="souhu:text_url"


LOG_LEVEL = 'INFO'
CONCURRENT_REQUESTS = 1  # 并发
DOWNLOAD_DELAY = 3  # 下载延迟
MONGO_URI="118.89.176.56:27017"
MONGO_DATABASE1="crawl_items"
MONGO_DATABASE2="crawl_news"



