#!/usr/bin/python
#-*- coding:utf-8 -*-
import logging
from termcolor import colored
from colorlog import ColoredFormatter
__author__ = 'supernew'


handlers = {
            'MONGODB':"mongodb.log",
            'REDIS':"redis.log",
            'CRAWL_URLS':"crawl_urls.log",
            'CRAWL_ITEMS':"crawl_items.log",
            }

##定义一个StreamHandler，通过setLevel将相应级别或更高的日志信息打印到标准错误
class Logger:
    def __init__(self, path,clevel = logging.DEBUG,Flevel = logging.DEBUG):
        self.logger = logging.getLogger('SpiderLogger')
        self.logger.setLevel(logging.DEBUG)
        #定义日志输出到cmd颜色
        LOGFORMAT = "%(log_color)s[%(asctime)s] %(filename)s [line:%(lineno)d][%(levelname)s] %(message)s"
        formatter = ColoredFormatter(LOGFORMAT)
        fmt = logging.Formatter('[%(asctime)s] %(filename)s[line:%(lineno)d] [%(levelname)s] %(message)s', '%Y-%m-%d %H:%M:%S')
        #设置CMD日志
        sh = logging.StreamHandler()
        sh.setFormatter(formatter)
        sh.setLevel(clevel)
        #设置文件日志
        fh = logging.FileHandler(path)
        fh.setFormatter(fmt)
        fh.setLevel(Flevel)
        self.logger.addHandler(sh)
        self.logger.addHandler(fh)

    def debug(self,message):
        message = colored(message, 'blue')
        self.logger.debug(message)

    def info(self,message):
        self.logger.info(message)

    def war(self,message):
        message = colored(message, 'blue')
        self.logger.warn(message)

    def error(self,message):

        self.logger.error(message)


    def cri(self,message):
        self.logger.critical(message)



if __name__ =='__main__':
    logyyx = Logger('scrapy.log',logging.WARNING,logging.DEBUG)
    logyyx.debug('一个debug信息')
    logyyx.info('一个info信息')
    logyyx.war('一个warning信息')
    logyyx.error('一个error信息')
    logyyx.cri('一个致命critical信息')