import urllib.request
import re
from bs4 import BeautifulSoup,Comment

def getcontentfromweb(src):  #获取网页
  req = urllib.request.Request(src)
  response = urllib.request.urlopen(req)
  try:
    html_page = response.read().decode('utf-8')
  except:
    response = urllib.request.urlopen(req)
    html_page = response.read().decode('gbk')
  return html_page

def filter_tags(html_str):#去除各种标签
    soup =BeautifulSoup(html_str)
    [script.extract() for script in soup.findAll('script')]
    [style.extract() for style in soup.findAll('style')]
    comments = soup.findAll(text=lambda text: isinstance(text, Comment))
    [comment.extract() for comment in comments]
    reg1 = re.compile("<[^>]*>")
    content = reg1.sub('', soup.prettify()).split('\n')
    return content

def getcontent(lst):#获取正文
    lstlen = [len(x) for x in lst]
    threshold=50
    startindex = 0
    maxindex = lstlen.index(max(lstlen))
    endindex = 0
    for i,v in enumerate(lstlen[:maxindex-3]):
        if v> threshold and lstlen[i+1]>5 and lstlen[i+2]>5 and lstlen[i+3]>5:
            startindex = i
            break
    for i,v in enumerate(lstlen[maxindex:]):
        if v< threshold and lstlen[maxindex+i+1]<10 and lstlen[maxindex+i+2]<10 and lstlen[maxindex+i+3]<10:
            endindex = i
            break
    content =['*'+x.strip()+'*' for x in lst[startindex:endindex+maxindex] if len(x.strip())>0]
    return content

def run(url): #运行函数
    ctthtml=getcontentfromweb(url)
    content =filter_tags(ctthtml)
    newcontent =getcontent(content)
    ctt =''.join(newcontent)
    hj=ctt.split("**")
    con=''
    for i in hj:
      if i!="":
        if regex(i):
          con+="<p>"+i+"</p>"
    return con


def is_chinese(uchar):
  """判断一个unicode是否是汉字"""
  zhPattern = re.compile(u'[\u4e00-\u9fa5]+')#中文字符
  match = zhPattern.search(uchar)
  if match:
    return True
  else:
    return False

def regex(stri): #判断中文在字符串中的比例
  leng=len(stri)
  L=0
  for x in stri:
    if is_chinese(x):
      L+=1
  if L/leng>0.1:
    return True