# encoding: utf-8
from PyQt4 import QtCore, QtGui, uic
import sys
import redis
from crawl_goodsitems import Downloaditems
from crawl_urls import crawl_urls
from scheduler import Scheduler
import settings
import threading
from manage_thread import Job

__author__ = 'supernew'


qtCreatorFile = "Spider_GUI/mainwindow.ui" # Enter file here.

Ui_MainWindow, QtBaseClass = uic.loadUiType(qtCreatorFile)
class MyApp(QtGui.QMainWindow, Ui_MainWindow):
    def __init__(self):
        QtGui.QMainWindow.__init__(self)
        Ui_MainWindow.__init__(self)
        self.setupUi(self)
        self.crawl_signal = threading.Event()
        self.crawl_signal.set()
        self.crawl_thread = threading.Thread(target=self.start_crawl, args=(self.crawl_signal,))
        self.stop_thread=threading.Thread(target=self.stop_crawl,args=(self.crawl_signal,))
        #self.crawl_job=Job(self.start_crawl)
        #self.stop_job=Job(stop_thread)
        self.crawlButton.clicked.connect(lambda:self.crawl_thread.start())
        self.stopButton.clicked.connect(lambda:self.stop_thread.start())
        self.watchButton.clicked.connect(lambda:self.startwatch())
    def  start_crawl(self,event):
        #爬取网页的目标路径
        event.wait()
        print "The Spider start to work..."
        rooturl=str(self.crawlurl.toPlainText())
        if crawl_urls(rooturl):
            jditems=Downloaditems()
            Redis_server= redis.Redis('118.89.176.56',6379)
            dupefilter_key=settings.JD_DUPEFILTER_KEY
            urls_queue_key=settings.JD_URLS_QUEUE_KEY
            goods_queue_key=settings.JD_GOODS_QUEUE_KEY
            crawl_scheduler=Scheduler(Redis_server,dupefilter_key,urls_queue_key,goods_queue_key)
            jditems.downloaditems(crawl_scheduler)
        else:
            return

    def stop_crawl(self,event):
        self.crawl_signal.clear()
        print 'The Spider has been stopped...'
        event.wait()
    def startwatch(self):
        QtGui.QMessageBox.about(self, "tip", "Please open the url:http://118.89.176.56:27017/\nint the browser!")
        print('ok clicked')


if __name__ == "__main__":
    app = QtGui.QApplication(sys.argv)
    window = MyApp()
    window.show()
    sys.exit(app.exec_())
