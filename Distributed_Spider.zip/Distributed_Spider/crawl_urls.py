# encoding: utf-8
import random
import re
from lxml import etree
import urllib2
import test_proxy_ip

from scheduler import Scheduler
from logger import Logger
import settings
import logging
__author__ = 'supernew'
import redis
def crawl_urls(rooturl):
    Redis_server= redis.Redis('118.89.176.56',6379)
    if 'jd' in rooturl:
        dupefilter_key=settings.JD_DUPEFILTER_KEY
        urls_queue_key=settings.JD_URLS_QUEUE_KEY
        goods_queue_key=settings.JD_GOODS_QUEUE_KEY
        crawl_scheduler=Scheduler(Redis_server,dupefilter_key,urls_queue_key,goods_queue_key)
    if 'taobao' in rooturl:
        dupefilter_key=settings.TB_DUPEFILTER_KEY
        urls_queue_key=settings.TB_URLS_QUEUE_KEY
        goods_queue_key=settings.TB_GOODS_QUEUE_KEY
        crawl_scheduler=Scheduler(Redis_server,dupefilter_key,urls_queue_key,goods_queue_key)
    if '163' in rooturl:
        dupefilter_key=settings.WY_DUPEFILTER_KEY
        urls_queue_key=settings.WY_URLS_QUEUE_KEY
        goods_queue_key=settings.WY_GOODS_QUEUE_KEY
        crawl_scheduler=Scheduler(Redis_server,dupefilter_key,urls_queue_key,goods_queue_key)

    #定义日志的记录信息
    crawl_urls_logger= Logger('log/crawl_urls.log',logging.DEBUG,logging.DEBUG)
    """#判断待爬取的url是否为空，若为空则把根路径入队列，否则直接从爬取队列上取url爬取
    if crawl_scheduler.get_urls_queue_len()==0:
        #判断去重队列里是否存在rooturl,若存在则删除去重队列
        if not crawl_scheduler.enqueue_url(rooturl):
            crawl_scheduler.close_df()
            message="the DupeFilter Queue has been updated!:"
            crawl_urls_logger.debug(message)
        #去重队列更新后，url可重新进队"""


    crawl_scheduler.enqueue_url(rooturl)
    message="the url has been pushed into the queue "+urls_queue_key+":"+rooturl
    crawl_urls_logger.info(message)

    #如果待爬取的url不为空，则循环取出队列进行爬取
    while(crawl_scheduler.get_urls_queue_len()>0):
        #如果爬取到的商品列表的目的路径达到指定的数量，则停止爬取
        if crawl_scheduler.get_goods_queue_len()>=settings.CRAWL_URL_nums:
            break
        else:
            headers = {}
            hrefs=''
            url=crawl_scheduler.get_crawl_url()
            message="the Spider starts to crawl the url: "+url
            crawl_urls_logger.info(message)#为了下载更可靠，控制用户代理的设定
            headers['User-agent'] = random.choice(settings.USER_AGENTS)
            try:
                request=urllib2.Request(url, headers=headers)
                proxies=test_proxy_ip.get_random_ip()  #设置随机获取的代理
                proxy_s=urllib2.ProxyHandler(proxies)
                opener=urllib2.build_opener(proxy_s)
                urllib2.install_opener(opener)
                response = urllib2.urlopen(request)
                html_page = response.read()
                if '163'in url:
                    html = etree.HTML(html_page)
                else:
                    html = etree.HTML(html_page.lower())
                hrefs = html.xpath(u"//a")
            except urllib2.HTTPError, Arguments:
                crawl_urls_logger.error(Arguments)
            except IOError, Arguments:
                crawl_urls_logger.error(Arguments)
            except Exception, Arguments:
                crawl_urls_logger.error(Arguments)

            for href in hrefs:
                try:
                    if 'href' in href.attrib:
                        val = href.attrib['href']

                        if val.startswith('//'):
                            if matchurl(val):
                                val = 'https:' + val
                                crawl_scheduler.enqueue_url(val)
                                  #如果爬取到的商品列表的目的路径达到指定的数量，则停止入队
                                if crawl_scheduler.get_goods_queue_len()>=settings.CRAWL_URL_nums:
                                   break
                            else:
                                  continue

                        if (val.startswith('https') or val.startswith('http')) and matchurl(val):
                            crawl_scheduler.enqueue_url(val)
                              #如果爬取到的商品列表的目的路径达到指定的数量，则停止入队
                            if crawl_scheduler.get_goods_queue_len()>=settings.CRAWL_URL_nums:
                               break
                        else:
                                  continue



                except ValueError,e:
                    crawl_urls_logger.cri(e)
                    continue

    return True

#定义url的匹配函数
def matchurl(url):
    for str in settings.NO_MATCHING:
        if str in url:
            return False
        else:
            continue
    return True




if __name__ == "__main__":
    rooturl="http://news.163.com/"
    obj_spider = crawl_urls(rooturl)

