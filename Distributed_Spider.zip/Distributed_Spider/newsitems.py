__author__ = 'supernew'
class newsItem():
    title = ''  # 商品链接
    text = ''  # 商品ID