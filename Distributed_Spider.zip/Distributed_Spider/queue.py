# encoding=utf-8
#定义一个先进先出的url爬取队列
#1.一个待爬取的url队列 2.特定商品列表url队列
import logging
import datetime
from logger import Logger


class Spider_url_Queue():

    def __init__(self, server, key):
        """Initialize per-spider redis queue.
        Parameters:
            server -- redis connection
            key -- key for this queue (e.g. "%(spider)s:queue")
        """
        self.server = server
        self.key = key


    #查询ur队列当中元素的个数
    def get_len(self):
        """Return the length of the queue"""
        return self.server.llen(self.key)

    #lpush(name,values)
    #在name对应的list中添加元素，每个新的元素都添加到列表的最左边"""
    def push(self, url):
        """Push a url"""
        self.server.lpush(self.key, url)

    #将多个列表排列,按照从右向左移除各个列表内的元素
    #timeout：取数据的列表没元素后的阻塞时间，0为一直阻塞
    def pop(self, timeout=0):
        """Pop a url"""
        if timeout > 0:
            url=self.server.brpop(self.key, timeout)
        else:
            url= self.server.rpop(self.key)
        if url==None:
            return False
        else:
            return url

    def clear(self):
        """Clear queue/stack"""
        self.server.delete(self.key)

