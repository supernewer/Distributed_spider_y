# encoding=utf-8
import logging
import datetime
import re
from dupefilter import DupeFilter
from spider_graphite import RedisGraphiteStatsCollector
import settings
from logger import Logger
from queue import Spider_url_Queue

#定义url爬取队列的调度器

SCHEDULER_PERSIST = False
IDLE_BEFORE_CLOSE = 3 #阻塞时间
class Scheduler(object):
    """Redis-based scheduler"""
    #Scheduler(Redis_server,dupefilter_key,urls_queue_key,goods_queue_key)
    def __init__(self, server, dupefilter_key, urls_queue_key,goods_queue_key):
        self.redis_logger= Logger('log/Redis.log',logging.DEBUG,logging.DEBUG)
        self.server = server
        self.persist = SCHEDULER_PERSIST
        self.idle_before_close = SCHEDULER_PERSIST
        self.urls_queue =Spider_url_Queue(server, urls_queue_key)
        self.goods_queue=Spider_url_Queue(server, goods_queue_key)
        self.df = DupeFilter(server, dupefilter_key)
        #定义四种爬取情况的记录时间
        self.enqueue_allurls_time=datetime.datetime.now()
        self.enqueue_goodslist_time=datetime.datetime.now()
        self.popqueue_allurls_time=datetime.datetime.now()
        self.popqueue_goodslist_time=datetime.datetime.now()
        self.last_time=''#定义最后爬取的时间
        #定义记录四种爬取情况前后的数目
        #url入队的两种情况
        self.url_num1_first=0
        self.url_num1_last=0
        self.url_num2_first=0
        self.url_num2_last=0
        #url出队的两种情况
        self.url_num3_first=0
        self.url_num3_last=0
        self.url_num4_first=0
        self.url_num4_last=0
        #目标url的限制数目
        self.url_num=0
        #定义graphite服务器的数据收集器
        self.urls_Collector=RedisGraphiteStatsCollector()
        #监控服务器相应的表项
        self.collector_key1="redis_crawl_allurls_nums"#爬取到的所有的url的数目
        self.collector_key2="redis_crawl_goodslisturls_nums"#爬取到的商品列表的url数目
        self.collector_key3="redis_download_allurls_nums"#取出url进行爬取的数目
        self.collector_key4="redis_download_goodslisturls_nums"#取出商品列表url进行爬取的数目



    def get_urls_queue_len(self):
        return self.urls_queue.get_len()
    def get_goods_queue_len(self):
        return self.goods_queue.get_len()

    def close_df(self):
        if not self.persist:
            self.df.clear()
    #url入队
    def enqueue_url(self,  url):
        if self.df.request_seen(url):
            return False
        self.urls_queue.push(url)
        message="the url has been pushed into the urls queue :"+url
        self.redis_logger.info(message)
        #进行redis入队信息的日志记录
        self.url_num1_last=self.url_num1_last+1
        self.last_time=datetime.datetime.now()
        interval=self.last_time-self.enqueue_allurls_time
        total_sec = interval.total_seconds()
        if total_sec>60 and total_sec<70:
            num=self.url_num1_last-self.url_num1_first
            self.url_num1_first=self.url_num1_last
            self.enqueue_allurls_time=self.last_time
            self.urls_Collector._set_value(self.collector_key1,num)
            message='The Spider has crawled %s urls around one minutes'%num
            self.redis_logger.info(message)
        #判别url是否是符合目的路径的商品列表url
        jdstr = "list.html?"
        tburl = "list?"
        wyurl="163"
        #判别是电商网站
        if (jdstr in url) or (tburl in url):
            self.url_num=self.url_num+1
            if self.url_num>0 and self.url_num<=settings.CRAWL_URL_nums:
                print "%s downloading %s " % (self.url_num, url)
                self.goods_queue.push(url)
                #进行redis入队信息的记录
                self.url_num2_last=self.url_num2_last+1
                self.last_time=datetime.datetime.now()
                interval=self.last_time-self.enqueue_goodslist_time
                total_sec = interval.total_seconds()
                if total_sec>60 and total_sec<70:
                    num=self.url_num2_last-self.url_num2_first
                    self.url_num2_first=self.url_num2_last
                    self.enqueue_goodslist_time=self.last_time
                    self.urls_Collector._set_value(self.collector_key2,num)
                    message='The Spider has crawled %s goodsitems_urls around one minutes'%num
                    self.redis_logger.info(message)
                message="the url of goods list has been pushed into the goods_queue :"+url
                self.redis_logger.info(message)
            if self.url_num ==settings.CRAWL_URL_nums:
                message="the urls in the goods_queue have reached the limit!"
                self.redis_logger.debug(message)
 #判别网易的url
        if wyurl in url:
             h=re.match(r'^http://news.163.com/\w{4,7}/$',url)
             if h and "photo" not in h.group() and "index" not in h.group() and "review" not in h.group() and "weather" not in h.group():
                 url=h
                 self.url_num=self.url_num+1
                 if self.url_num>0 and self.url_num<=settings.CRAWL_URL_nums:
                    print "%s downloading %s " % (self.url_num, url)
                    self.goods_queue.push(url)
                    #进行redis入队信息的记录
                    self.url_num2_last=self.url_num2_last+1
                    self.last_time=datetime.datetime.now()
                    interval=self.last_time-self.enqueue_goodslist_time
                    total_sec = interval.total_seconds()
                    if total_sec>60 and total_sec<70:
                        num=self.url_num2_last-self.url_num2_first
                        self.url_num2_first=self.url_num2_last
                        self.enqueue_goodslist_time=self.last_time
                        self.urls_Collector._set_value(self.collector_key2,num)
                        message='The Spider has crawled %s newsitems_urls around one minutes'%num
                        self.redis_logger.info(message)
                    message="the url of goods list has been pushed into the news_queue :"+url
                    self.redis_logger.info(message)
                 if self.url_num ==settings.CRAWL_URL_nums:
                    message="the urls in the goods_queue have reached the limit!"
                    self.redis_logger.debug(message)



    #取第一个队列中的url
    def get_crawl_url(self):
        crawl_url = self.urls_queue.pop()

        self.url_num3_last=self.url_num3_last+1
        self.last_time=datetime.datetime.now()
        interval=self.last_time-self.popqueue_allurls_time
        total_sec = interval.total_seconds()
        if (total_sec>60) or(total_sec>60 and total_sec<70):
            num=self.url_num3_last-self.url_num3_first
            self.url_num3_first=self.url_num3_last
            self.popqueue_allurls_time=self.last_time
            self.urls_Collector._set_value(self.collector_key3,num)
            message='The crawl_queue has popped %s urls around one minutes'%num
            self.redis_logger.info(message)
        return crawl_url

    #取第二队列中目标商品列表的url
    def get_goods_url(self):
        block_pop_timeout = self.idle_before_close
        goods_url= self.goods_queue.pop(block_pop_timeout)
        self.url_num4_last=self.url_num4_last+1
        self.last_time=datetime.datetime.now()
        interval=self.last_time-self.enqueue_goodslist_time
        total_sec = interval.total_seconds()
        if (total_sec>60) or(total_sec>60 and total_sec<70):
            num=self.url_num4_last-self.url_num4_first
            self.url_num4_first=self.url_num4_last
            self.enqueue_goodslist_time=self.last_time
            self.urls_Collector._set_value(self.collector_key4,num)
            message='The goodslist_queue has popped %s urls around one minutes'%num
            self.redis_logger.info(message)
        return goods_url


    def has_pending_requests(self):
        return len(self) > 0


